//
//  MenuOption.swift
//  GOW
//
//  Created by Rafael Gonzalez on 07/03/25.
//

struct MenuOption {
    let title : String
    let image : String
    let segue : String
}
