//
//  Weapon.swift
//  GOW
//
//  Created by Rafael Gonzalez on 07/03/25.
//



struct Weapon {
    let id : Int
    let name : String
    let description: String
    let poster : String
}
